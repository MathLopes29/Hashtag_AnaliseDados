/*
a.  Qual a quantidade de prontuários?
*/
SELECT COUNT(*) FROM DADOS_MEDICOS


/*
b.  Qual a média de altura e peso dos pacientes por idade?
*/
SELECT      IDADE,
            AVG(CAST(ALTURA AS FLOAT)) AS MEDIA_ALTURA,
            AVG(CAST(PESO AS FLOAT)) AS MEDIA_PESO
FROM        DADOS_MEDICOS
GROUP BY    IDADE


/*
c.  Qual é a quantidade de pacientes por faixa etária dos pacientes que possuem pressão alta (considere pressão alta valores acima de 140/100).
*/
SELECT      FAIXA_ETARIA, COUNT(*) AS QTDE
FROM        "@azureuser"."dados_medicos"
WHERE       PRESSAO_SISTOLICA >= 140
AND         PRESSAO_DIASTOLICA >= 100
GROUP BY    FAIXA_ETARIA


/*
d.  Quantos pacientes foram avaliados mais de uma vez? (considere o campo NOME para avaliar). 
Dos pacientes que foram avaliados mais de uma vez, qual a média, maior e menor valor da temperatura, 
batimentos cardíacos e saturação de oxigênio?
*/
SELECT      NOME,
            MAX(CAST(SATURACAOOXIGENIO AS FLOAT)) AS MAIOR_SATURACAOOXIGENIO,
            MAX(CAST(TEMPERATURA AS FLOAT)) AS MAIOR_TEMPERATURA,
            MAX(CAST(BATIMENTOSCARDIACOS AS FLOAT)) AS MAIOR_BATIMENTOSCARDIACOS,
            MIN(CAST(SATURACAOOXIGENIO AS FLOAT)) AS MENOR_SATURACAOOXIGENIO,
            MIN(CAST(TEMPERATURA AS FLOAT)) AS MENOR_TEMPERATURA,
            MIN(CAST(BATIMENTOSCARDIACOS AS FLOAT)) AS MENOR_BATIMENTOSCARDIACOS,
            AVG(CAST(SATURACAOOXIGENIO AS FLOAT)) AS MEDIA_SATURACAOOXIGENIO,
            AVG(CAST(TEMPERATURA AS FLOAT)) AS MEDIA_TEMPERATURA,
            AVG(CAST(BATIMENTOSCARDIACOS AS FLOAT)) AS MEDIA_BATIMENTOSCARDIACOS
FROM        DATALAKE."datalake-1666264".bronze."dados_medicos_20260511_233534.csv"
WHERE       NOME IN (
                        SELECT      NOME
                        FROM        DATALAKE."datalake-1666264".bronze."dados_medicos_20260511_233534.csv"
                        GROUP BY    NOME
                        HAVING      COUNT(*) > 1
                    )
GROUP BY    NOME