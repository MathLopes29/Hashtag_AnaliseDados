from airflow import DAG
from airflow.providers.docker.operators.docker import DockerOperator
from datetime import datetime, timedelta
from docker.types import Mount

usuario = 'azureuser' # Substitua pelo nome do usuario do arquivo de variaveis

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.now(),
    'email': ['1666264@sga.pucminas.br'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=60),
}

dag = DAG(
    'DAG_INGESTAO_DADOS_ALUNOS',
    default_args=default_args,
    description='DAG para transformar os dados de alunos e criar a camada gold com dados normalizados',
    schedule_interval='0 */2 * * *',
)

ingestao_dados_alunos = DockerOperator(
    task_id='INGESTAO_DADOS_ALUNOS',
    image='pyspark-notebook-custom',  # Imagem jupyter configurada no ambiente onde o Docker está instalado
    command="bash -c 'papermill /home/jovyan/manipular_dados_alunos.ipynb /home/jovyan/output_manipular_dados_alunos.ipynb'",
    docker_url='unix://var/run/docker.sock',  # Caminho do socket Docker, para execucao entre containeres
    network_mode='bridge',
    auto_remove=True,
    dag=dag,
    mount_tmp_dir=False,  # Se não for usar volume do host,
    mounts=[
        Mount(source=f"/home/{usuario}/notebooks", target="/home/jovyan", type="bind"),
        Mount(source=f"/home/{usuario}/data", target="/home/jovyan/data", type="bind")
    ]
)