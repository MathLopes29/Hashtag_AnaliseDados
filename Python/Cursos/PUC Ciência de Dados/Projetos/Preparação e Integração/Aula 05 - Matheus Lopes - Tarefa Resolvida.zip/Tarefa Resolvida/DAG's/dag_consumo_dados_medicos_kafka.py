from airflow import DAG
from airflow.providers.docker.operators.docker import DockerOperator
from datetime import datetime, timedelta
from docker.types import Mount

usuario = "azureuser" # Digite o nome do usuario da máquina virtual (azureuser)

default_args = {
    'start_date': datetime.now(),
    'catchup': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=1)
}

dag = DAG(
    'DAG_CONSUMO_DADOS_MEDICOS_KAFKA',
    description='DAG que consome dados medicos no apache Kafka',
    default_args=default_args,
    schedule_interval='*/10 * * * *'
)

consumir_dados_kafka = DockerOperator(
    task_id='CONSUMIR_DADOS_KAFKA',
    image='pyspark-notebook-custom',  # Imagem jupyter configurada no ambiente onde o Docker está instalado
    command="bash -c 'papermill /home/jovyan/notebook_ingestao_datalake_dados_kafka.ipynb /home/jovyan/output_notebook_ingestao_datalake_dados_kafka.ipynb'",
    docker_url='unix://var/run/docker.sock',  # Caminho do socket Docker, para execucao entre containeres
    network_mode='bridge', # Coloque o nome da rede Docker (se estiver usando WSL, utilize o nome da rede default - use o comando docker network ls para obter o nome)
    auto_remove=True,
    dag=dag,
    mount_tmp_dir=False,  # Se não for usar volume do host,
    mounts=[
        Mount(source=f"/home/{usuario}/notebooks", target="/home/jovyan", type="bind"),
        Mount(source=f"/home/{usuario}/data", target="/home/jovyan/data", type="bind")
    ]
)

consumir_dados_kafka